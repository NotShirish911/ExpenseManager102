"""Input validation.

Two layers:
  * Pure checker functions (parse_amount, is_valid_date, ...) - easy to unit test.
  * prompt_* helpers that loop until the user gives valid input (FR11).
"""
import math
from datetime import datetime

MAX_AMOUNT = 1000000.0
MIN_YEAR, MAX_YEAR = 2000, 2100
MAX_TEXT_LENGTH = 60


# ---------- pure checkers ----------
def parse_amount(text):
    """Return a positive float rounded to 2 dp, or None if the text is not valid."""
    try:
        value = float(str(text).strip())
    except ValueError:
        return None
    if not math.isfinite(value):
        return None
    value = round(value, 2)
    if value <= 0 or value > MAX_AMOUNT:
        return None
    return value


def is_valid_date(text):
    """True for a real calendar date written exactly as YYYY-MM-DD."""
    text = str(text).strip()
    if len(text) != 10:
        return False
    try:
        parsed = datetime.strptime(text, "%Y-%m-%d")
    except ValueError:
        return False
    return MIN_YEAR <= parsed.year <= MAX_YEAR


def is_valid_month(text):
    """True for a real month written exactly as YYYY-MM."""
    text = str(text).strip()
    if len(text) != 7:
        return False
    try:
        parsed = datetime.strptime(text, "%Y-%m")
    except ValueError:
        return False
    return MIN_YEAR <= parsed.year <= MAX_YEAR


def parse_menu_choice(text, low, high):
    """Return the integer choice if it is within [low, high], otherwise None."""
    text = str(text).strip()
    if not (text.isascii() and text.isdigit()):
        return None
    value = int(text)
    if low <= value <= high:
        return value
    return None


# ---------- re-prompting helpers ----------
def _with_default(label, default):
    if default is None:
        return "%s: " % label
    return "%s [%s]: " % (label, default)


def prompt_text(label, default=None):
    """Ask for non-empty text (max 60 characters). Enter keeps the default if given."""
    while True:
        raw = input(_with_default(label, default)).strip()
        if raw == "" and default is not None:
            return default
        if raw == "":
            print("  Input cannot be empty.")
        elif len(raw) > MAX_TEXT_LENGTH:
            print("  Please use %d characters or fewer." % MAX_TEXT_LENGTH)
        else:
            return raw


def prompt_amount(label, default=None):
    """Ask for a positive amount (up to 1,000,000)."""
    shown = None if default is None else "%.2f" % default
    while True:
        raw = input(_with_default(label, shown)).strip()
        if raw == "" and default is not None:
            return default
        amount = parse_amount(raw)
        if amount is None:
            print("  Enter a number greater than 0 and at most %.0f." % MAX_AMOUNT)
        else:
            return amount


def prompt_date(label, default=None):
    while True:
        raw = input(_with_default(label, default)).strip()
        if raw == "" and default is not None:
            return default
        if is_valid_date(raw):
            return raw
        print("  Enter a real date as YYYY-MM-DD (for example 2026-10-31).")


def prompt_month(label):
    while True:
        raw = input("%s: " % label).strip()
        if is_valid_month(raw):
            return raw
        print("  Enter a month as YYYY-MM (for example 2026-10).")


def prompt_choice(label, low, high):
    while True:
        choice = parse_menu_choice(input("%s: " % label), low, high)
        if choice is not None:
            return choice
        print("  Enter a number from %d to %d." % (low, high))


def prompt_yes_no(label):
    while True:
        raw = input("%s (Y/N): " % label).strip().lower()
        if raw in ("y", "yes"):
            return True
        if raw in ("n", "no"):
            return False
        print("  Please answer Y or N.")
