# Expense Manager (ICT102 – Topic C)

A modular, menu-driven Python console application for tracking expenses.

## Requirements
- Python 3.8 or newer (tested on 3.12). No extra packages: only the standard library is used.

## Run
```
cd <project folder>
python main.py          # use python3 on macOS/Linux if needed
```
The program loads `data/expenses.csv` (10 sample records included) and saves back to it when you choose **0. Save and exit**. If the file does not exist it is created automatically.

In VS Code: open the project folder, open `main.py`, and press the Run button, or run the command above in the integrated terminal (Ctrl+`).

## Run the tests
```
python -m unittest discover -s tests -v
```

## Project structure
| File | Responsibility |
|---|---|
| `main.py` | Menu loop and menu handlers (FR1, FR12) |
| `manager.py` | `ExpenseManager` class: add, update, delete, search, filter, monthly total |
| `models.py` | `Expense` dataclass and CSV row conversion |
| `storage.py` | Load/save CSV, create missing file (FR9) |
| `reports.py` | `recursive_total` (FR10), per-category totals, largest, average (FR8) |
| `display.py` | Aligned tables and summary report output (FR3) |
| `validation.py` | Validators and re-prompting input helpers (FR11) |
| `tests/` | Automated tests |
| `data/expenses.csv` | Sample data (10 records) |

## Menu
1 Add · 2 View all · 3 Search (description / category / ID) · 4 Update · 5 Delete (with Y/N) · 6 Filter by category · 7 Filter by month · 8 Monthly total · 9 Summary report · 0 Save and exit

## Data format
CSV with header `id,date,category,description,amount`. Dates are `YYYY-MM-DD`.

## Version control
Commit regularly with meaningful messages, for example:
```
git init
git add .
git commit -m "Add validation helpers"
git log --oneline
```
