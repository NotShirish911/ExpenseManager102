# ICT102 Assessment – Expense Manager (Topic C)

**Student:** [Your name] – [Student ID]

## Program overview
Expense Manager is a modular, menu-driven Python console application. Users add, view, search, update and delete expenses (ID, date, category, description, amount), filter by category or month, see a monthly total, and view a summary report (total spent, total per category, largest and average expense). Records are loaded from `data/expenses.csv` at start-up and saved on exit; if the file is missing it is created.

## Design choices
- **Separation of responsibilities.** `main.py` only runs the menu. `manager.py` (the `ExpenseManager` class) holds the records and operations. `storage.py` handles CSV, `reports.py` does calculations, `display.py` prints, `validation.py` checks input, and `models.py` defines the `Expense` dataclass. Each file has one job, so a change in one place rarely affects another.
- **Pure checkers plus prompt loops.** Validation functions such as `parse_amount` return a value or `None`, so they are easy to unit test. The `prompt_*` helpers wrap them in loops that re-prompt until the input is valid, so empty, non-numeric, negative, out-of-range and unknown-ID input never crash the program.
- **Recursion.** `recursive_total` adds amounts by splitting the list in half (base cases: empty or one item). Halving keeps recursion depth near log2(n), so long lists cannot exceed Python's recursion limit. It is used for the total spent and the monthly total.
- **Own loops.** The largest expense, per-category totals and counts use explicit loops, as FR8 requires.
- **Robust files.** Invalid or duplicate CSV rows are skipped with a warning instead of crashing. Ctrl+C or closed input still saves before exit.

## Testing summary
28 automated `unittest` tests cover normal, boundary and error cases (see `TEST_CASES.md`). They include scripted end-to-end sessions with deliberately bad input. All tests pass.

## Reflection and improvements
[Write this part in your own words. Points you could cover: what was hardest, what you learned, and what you would change.] For example: separating validation from input made bugs easier to find, because I could test each rule on its own. Writing the tests early showed edge cases I had not thought of, such as a leap-day date and amounts that round to zero. If I had more time I would add budgets per category, a currency setting, and an undo option. I would also store dates as `datetime.date` objects instead of strings.

## Acknowledgement of assistance
[Edit to match what you actually did.] I used Claude (Anthropic) to help generate the initial code and tests. I read, ran and tested the code, and I understand how each module works.
