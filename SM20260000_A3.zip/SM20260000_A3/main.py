"""Expense Manager - modular, menu-driven console application (Project topic C).

Run with:  python main.py
"""
import os

import display
import validation as v
from manager import ExpenseManager
from reports import build_summary
from storage import load_expenses, save_expenses

DATA_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "expenses.csv")

MENU = """
========== EXPENSE MANAGER ==========
 1. Add an expense
 2. View all expenses
 3. Search expenses
 4. Update an expense
 5. Delete an expense
 6. Filter by category
 7. Filter by month
 8. Monthly total
 9. Summary report
 0. Save and exit
====================================="""


def ask_for_expense(manager, action):
    """Ask for an ID until it exists. Returns the expense, or None if the user cancels."""
    while True:
        raw = input("ID of the expense to %s (Enter to cancel): " % action).strip()
        if raw == "":
            return None
        if not (raw.isascii() and raw.isdigit()):
            print("  IDs are whole numbers.")
            continue
        expense = manager.find_by_id(int(raw))
        if expense is None:
            print("  No expense with ID %s." % raw)
            continue
        return expense


def handle_add(manager):
    print("\n--- Add an expense ---")
    date = v.prompt_date("Date (YYYY-MM-DD)")
    category = v.prompt_text("Category").title()
    description = v.prompt_text("Description")
    amount = v.prompt_amount("Amount")
    expense = manager.add(date, category, description, amount)
    print("Added expense with ID %d." % expense.id)


def handle_view(manager):
    display.show_table(manager.expenses)


def handle_search(manager):
    print("\n--- Search ---")
    print("Search by: 1. Description   2. Category   3. ID")
    field = v.prompt_choice("Choose 1-3", 1, 3)
    if field == 1:
        display.show_table(manager.search_description(v.prompt_text("Description contains")))
    elif field == 2:
        display.show_table(manager.search_category(v.prompt_text("Category contains")))
    else:
        found = manager.find_by_id(v.prompt_choice("ID", 1, 10 ** 9))
        display.show_table([found] if found else [])


def handle_update(manager):
    print("\n--- Update an expense ---")
    if not manager.expenses:
        print("There are no expenses to update.")
        return
    expense = ask_for_expense(manager, "update")
    if expense is None:
        return
    print("Press Enter to keep the current value.")
    date = v.prompt_date("Date", expense.date)
    category = v.prompt_text("Category", expense.category).title()
    description = v.prompt_text("Description", expense.description)
    amount = v.prompt_amount("Amount", expense.amount)
    manager.update(expense.id, date, category, description, amount)
    print("Expense %d updated." % expense.id)


def handle_delete(manager):
    print("\n--- Delete an expense ---")
    if not manager.expenses:
        print("There are no expenses to delete.")
        return
    expense = ask_for_expense(manager, "delete")
    if expense is None:
        return
    display.show_table([expense])
    if v.prompt_yes_no("Delete this expense?"):
        manager.delete(expense.id)
        print("Deleted.")
    else:
        print("Nothing was deleted.")


def handle_filter_category(manager):
    print("\n--- Filter by category ---")
    if not manager.expenses:
        print("There are no expenses yet.")
        return
    print("Categories in use: " + ", ".join(manager.categories()))
    category = v.prompt_text("Category")
    results = manager.filter_category(category)
    display.show_table(results)
    if results:
        print("Total for this category: %s" % display.money(build_summary(results)["total"]))


def handle_filter_month(manager):
    print("\n--- Filter by month ---")
    display.show_table(manager.filter_month(v.prompt_month("Month (YYYY-MM)")))


def handle_monthly_total(manager):
    print("\n--- Monthly total ---")
    month = v.prompt_month("Month (YYYY-MM)")
    print("Total spent in %s: %s" % (month, display.money(manager.monthly_total(month))))


def handle_summary(manager):
    display.show_summary(build_summary(manager.expenses))


ACTIONS = {
    1: handle_add, 2: handle_view, 3: handle_search, 4: handle_update, 5: handle_delete,
    6: handle_filter_category, 7: handle_filter_month, 8: handle_monthly_total, 9: handle_summary,
}


def main(data_file=DATA_FILE):
    expenses, warnings = load_expenses(data_file)
    for message in warnings:
        print("Warning: " + message)
    manager = ExpenseManager(expenses)
    print("Loaded %d expense(s)." % len(manager.expenses))

    try:
        while True:                                        # FR1: loop until Exit
            print(MENU)
            choice = v.parse_menu_choice(input("Choose an option (0-9): "), 0, 9)
            if choice is None:
                print("Invalid choice. Please enter a number from 0 to 9.")
                continue
            if choice == 0:
                break
            ACTIONS[choice](manager)
    except (KeyboardInterrupt, EOFError):
        print("\nInput ended - saving your data before exit.")

    try:
        save_expenses(data_file, manager.expenses)         # FR12: save on exit
    except OSError as error:
        print("Could not save the data file: %s" % error)
        return
    print("Data saved. Goodbye!")


if __name__ == "__main__":
    main()
