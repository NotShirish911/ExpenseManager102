"""Calculations for the summary report (FR8) and the recursive function (FR10).

Totals, averages and the largest value are calculated with our own loops.
"""


def recursive_total(values):
    """RECURSIVE FUNCTION (FR10): add up a list of numbers by divide and conquer.

    Base cases:      an empty list totals 0; a one-item list totals that item.
    Recursive case:  split the list in half and add the totals of the two halves.
    Splitting in half keeps the recursion depth near log2(n), so even very long
    expense lists cannot exceed Python's recursion limit.
    """
    if len(values) == 0:
        return 0.0
    if len(values) == 1:
        return values[0]
    middle = len(values) // 2
    return recursive_total(values[:middle]) + recursive_total(values[middle:])


def totals_per_category(expenses):
    """Return a list of (category, total) pairs, grouping names case-insensitively."""
    names = {}    # lower-case name -> first spelling seen
    totals = {}   # lower-case name -> running total
    for expense in expenses:
        key = expense.category.lower()
        if key not in totals:
            names[key] = expense.category
            totals[key] = 0.0
        totals[key] += expense.amount
    return [(names[key], round(totals[key], 2)) for key in totals]


def largest_expense(expenses):
    """Return the expense with the highest amount, or None for an empty list."""
    largest = None
    for expense in expenses:
        if largest is None or expense.amount > largest.amount:
            largest = expense
    return largest


def build_summary(expenses):
    """Return a dict with count, total, per_category, largest and average."""
    count = 0
    for _ in expenses:
        count += 1
    total = round(recursive_total([e.amount for e in expenses]), 2)
    average = round(total / count, 2) if count > 0 else 0.0
    return {
        "count": count,
        "total": total,
        "per_category": totals_per_category(expenses),
        "largest": largest_expense(expenses),
        "average": average,
    }
