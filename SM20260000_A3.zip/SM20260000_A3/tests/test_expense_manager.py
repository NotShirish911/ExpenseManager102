"""Automated tests (unittest). Run from the project folder with:
    python -m unittest discover -s tests -v
Covers normal, boundary and error cases.
"""
import contextlib
import io
import os
import sys
import tempfile
import unittest
from unittest import mock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import main as app                                    # noqa: E402
import validation as v                                # noqa: E402
from manager import ExpenseManager                    # noqa: E402
from models import Expense                            # noqa: E402
from reports import build_summary, recursive_total    # noqa: E402
from storage import load_expenses, save_expenses      # noqa: E402


def sample_manager():
    m = ExpenseManager()
    m.add("2026-09-03", "Food", "Groceries", 80.00)
    m.add("2026-09-10", "Transport", "Train ticket", 20.00)
    m.add("2026-10-01", "Food", "Lunch", 50.00)
    m.add("2026-10-15", "Housing", "Rent", 1000.00)
    return m


def run_quietly(func, *args):
    with contextlib.redirect_stdout(io.StringIO()) as out:
        result = func(*args)
    return result, out.getvalue()


class ValidationTests(unittest.TestCase):
    def test_amount_valid(self):
        self.assertEqual(v.parse_amount("12.5"), 12.5)
        self.assertEqual(v.parse_amount(" 0.01 "), 0.01)           # boundary: smallest
        self.assertEqual(v.parse_amount("1000000"), 1000000.0)     # boundary: largest

    def test_amount_invalid(self):
        for bad in ["", "   ", "abc", "-5", "0", "0.001", "1000000.01", "nan", "inf", "1e999", "12,50"]:
            self.assertIsNone(v.parse_amount(bad), bad)

    def test_date(self):
        self.assertTrue(v.is_valid_date("2026-10-31"))
        self.assertTrue(v.is_valid_date("2028-02-29"))             # leap day
        for bad in ["", "2026-02-30", "2026-13-01", "2026-1-5", "31/10/2026", "abcd-ef-gh", "1999-01-01"]:
            self.assertFalse(v.is_valid_date(bad), bad)

    def test_month(self):
        self.assertTrue(v.is_valid_month("2026-10"))
        for bad in ["", "2026-13", "2026-1", "2026", "10-2026"]:
            self.assertFalse(v.is_valid_month(bad), bad)

    def test_menu_choice(self):
        self.assertEqual(v.parse_menu_choice("3", 0, 9), 3)
        self.assertEqual(v.parse_menu_choice("0", 0, 9), 0)
        for bad in ["", "x", "-1", "10", "2.5", " "]:
            self.assertIsNone(v.parse_menu_choice(bad, 0, 9), bad)

    def test_prompt_amount_reprompts_until_valid(self):
        with mock.patch("builtins.input", side_effect=["", "abc", "-1", "0", "12.5"]):
            result, out = run_quietly(v.prompt_amount, "Amount")
        self.assertEqual(result, 12.5)
        self.assertEqual(out.count("Enter a number"), 4)

    def test_prompt_text_rejects_empty_and_too_long(self):
        with mock.patch("builtins.input", side_effect=["", "x" * 61, "Coffee"]):
            result, _ = run_quietly(v.prompt_text, "Description")
        self.assertEqual(result, "Coffee")

    def test_prompt_default_on_enter(self):
        with mock.patch("builtins.input", side_effect=[""]):
            result, _ = run_quietly(v.prompt_amount, "Amount", 9.5)
        self.assertEqual(result, 9.5)

    def test_prompt_yes_no(self):
        with mock.patch("builtins.input", side_effect=["maybe", "", "Y"]):
            result, _ = run_quietly(v.prompt_yes_no, "Sure?")
        self.assertTrue(result)


class RecursionTests(unittest.TestCase):
    def test_base_cases(self):
        self.assertEqual(recursive_total([]), 0.0)
        self.assertEqual(recursive_total([7.5]), 7.5)

    def test_matches_builtin_sum(self):
        values = [1.25, 2.5, 3.75, 10, 0.01]
        self.assertAlmostEqual(recursive_total(values), sum(values))

    def test_large_list_does_not_hit_recursion_limit(self):
        values = [1.0] * 20000
        self.assertEqual(recursive_total(values), 20000.0)


class ManagerTests(unittest.TestCase):
    def test_add_assigns_unique_ids(self):
        m = sample_manager()
        ids = [e.id for e in m.expenses]
        self.assertEqual(len(ids), len(set(ids)))
        m.delete(2)
        new = m.add("2026-11-01", "Food", "Snack", 5)
        self.assertNotIn(new.id, [e.id for e in m.expenses if e is not new])

    def test_search_is_case_insensitive_and_can_return_many(self):
        m = sample_manager()
        self.assertEqual(len(m.search_category("FOOD")), 2)
        self.assertEqual(len(m.search_description("tRaIn")), 1)
        self.assertEqual(m.search_description("zzz"), [])

    def test_filter_category_and_month(self):
        m = sample_manager()
        self.assertEqual(len(m.filter_category("food")), 2)
        self.assertEqual(len(m.filter_month("2026-09")), 2)
        self.assertEqual(m.filter_month("2030-01"), [])

    def test_monthly_total(self):
        m = sample_manager()
        self.assertEqual(m.monthly_total("2026-09"), 100.00)
        self.assertEqual(m.monthly_total("2026-10"), 1050.00)
        self.assertEqual(m.monthly_total("2030-01"), 0.0)

    def test_update(self):
        m = sample_manager()
        self.assertTrue(m.update(1, amount=99.99, category="Groceries"))
        self.assertEqual(m.find_by_id(1).amount, 99.99)
        self.assertEqual(m.find_by_id(1).category, "Groceries")
        self.assertFalse(m.update(999, amount=5))

    def test_delete(self):
        m = sample_manager()
        self.assertTrue(m.delete(1))
        self.assertIsNone(m.find_by_id(1))
        self.assertFalse(m.delete(1))


class ReportTests(unittest.TestCase):
    def test_summary(self):
        s = build_summary(sample_manager().expenses)
        self.assertEqual(s["count"], 4)
        self.assertEqual(s["total"], 1150.00)
        self.assertEqual(s["average"], 287.50)
        self.assertEqual(s["largest"].description, "Rent")
        self.assertEqual(dict(s["per_category"]), {"Food": 130.0, "Transport": 20.0, "Housing": 1000.0})

    def test_summary_empty(self):
        s = build_summary([])
        self.assertEqual((s["count"], s["total"], s["average"]), (0, 0.0, 0.0))
        self.assertIsNone(s["largest"])

    def test_category_names_group_case_insensitively(self):
        items = [Expense(1, "2026-01-01", "Food", "a", 10), Expense(2, "2026-01-02", "food", "b", 5)]
        self.assertEqual(build_summary(items)["per_category"], [("Food", 15.0)])


class StorageTests(unittest.TestCase):
    def test_missing_file_is_created(self):
        with tempfile.TemporaryDirectory() as folder:
            path = os.path.join(folder, "newdata", "expenses.csv")
            expenses, warnings = load_expenses(path)
            self.assertEqual((expenses, warnings), ([], []))
            self.assertTrue(os.path.exists(path))

    def test_round_trip_with_commas_and_quotes(self):
        with tempfile.TemporaryDirectory() as folder:
            path = os.path.join(folder, "e.csv")
            original = [Expense(1, "2026-05-05", "Food", 'Pizza, "large"', 23.5)]
            save_expenses(path, original)
            loaded, warnings = load_expenses(path)
            self.assertEqual(loaded, original)
            self.assertEqual(warnings, [])

    def test_bad_and_duplicate_rows_are_skipped(self):
        with tempfile.TemporaryDirectory() as folder:
            path = os.path.join(folder, "e.csv")
            with open(path, "w", newline="") as handle:
                handle.write("id,date,category,description,amount\n"
                             "1,2026-01-01,Food,Ok,10.00\n"
                             "x,2026-01-01,Food,Bad id,10.00\n"
                             "2,2026-02-30,Food,Bad date,10.00\n"
                             "3,2026-01-01,Food,Negative,-4\n"
                             "1,2026-01-01,Food,Duplicate,5.00\n"
                             "4,2026-01-01\n")
            loaded, warnings = load_expenses(path)
            self.assertEqual([e.id for e in loaded], [1])
            self.assertEqual(len(warnings), 5)

    def test_shipped_sample_file_has_at_least_8_valid_records(self):
        sample = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "expenses.csv")
        loaded, warnings = load_expenses(sample)
        self.assertGreaterEqual(len(loaded), 8)
        self.assertEqual(warnings, [])


class EndToEndTests(unittest.TestCase):
    def run_session(self, path, inputs):
        with mock.patch("builtins.input", side_effect=inputs):
            _, out = run_quietly(app.main, path)
        return out

    def test_session_with_bad_input_then_clean_exit(self):
        with tempfile.TemporaryDirectory() as folder:
            path = os.path.join(folder, "e.csv")
            out = self.run_session(path, [
                "", "abc", "99", "-1",                                  # invalid menu choices
                "2",                                                    # view: empty
                "1", "bad", "2026-10-05", "", "food", "", "Pizza", "x", "-3", "25.5",   # add with errors
                "3", "2", "FOO",                                        # search category (case-insensitive)
                "4", "abc", "77", "1", "", "", "", "30",                # update: bad IDs then change amount
                "8", "2026-13", "2026-10",                              # monthly total
                "9",                                                    # summary
                "5", "1", "maybe", "n",                                 # delete declined
                "5", "1", "y",                                          # delete confirmed
                "0",
            ])
            self.assertIn("Invalid choice", out)
            self.assertIn("No expenses to show", out)
            self.assertIn("Added expense with ID 1", out)
            self.assertIn("Expense 1 updated", out)
            self.assertIn("Total spent in 2026-10: 30.00", out)
            self.assertIn("Nothing was deleted", out)
            self.assertIn("Goodbye", out)
            loaded, _ = load_expenses(path)
            self.assertEqual(loaded, [])                                # deleted, then saved empty

    def test_data_persists_between_runs(self):
        with tempfile.TemporaryDirectory() as folder:
            path = os.path.join(folder, "e.csv")
            self.run_session(path, ["1", "2026-10-05", "Food", "Pizza", "25.5", "0"])
            out = self.run_session(path, ["2", "0"])
            self.assertIn("Loaded 1 expense(s)", out)
            self.assertIn("Pizza", out)

    def test_ctrl_d_or_closed_input_still_saves(self):
        with tempfile.TemporaryDirectory() as folder:
            path = os.path.join(folder, "e.csv")
            out = self.run_session(path, ["1", "2026-10-05", "Food", "Pizza", "25.5", EOFError()])
            self.assertIn("Goodbye", out)
            loaded, _ = load_expenses(path)
            self.assertEqual(len(loaded), 1)


if __name__ == "__main__":
    unittest.main()
