"""Data model for one expense record."""
from dataclasses import dataclass

from validation import is_valid_date, parse_amount

FIELDS = ["id", "date", "category", "description", "amount"]


@dataclass
class Expense:
    id: int
    date: str          # YYYY-MM-DD
    category: str
    description: str
    amount: float

    def to_row(self):
        """Values in the same order as FIELDS, ready for csv.writer."""
        return [self.id, self.date, self.category, self.description, "%.2f" % self.amount]

    @classmethod
    def from_row(cls, row):
        """Build an Expense from a csv.DictReader row. Raises ValueError if it is invalid."""
        try:
            expense_id = int(row["id"])
            date = (row["date"] or "").strip()
            category = (row["category"] or "").strip()
            description = (row["description"] or "").strip()
            amount = parse_amount(row["amount"] or "")
        except (KeyError, TypeError, AttributeError):
            raise ValueError("missing column or value")
        if expense_id <= 0 or not is_valid_date(date) or not category or not description or amount is None:
            raise ValueError("invalid field value")
        return cls(expense_id, date, category, description, amount)
