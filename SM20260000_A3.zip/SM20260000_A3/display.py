"""Console output: aligned tables and the summary report."""

DESC_WIDTH = 30
CAT_WIDTH = 16


def _fit(text, width):
    return text if len(text) <= width else text[:width - 3] + "..."


def money(value):
    return "{:,.2f}".format(value)


def show_table(expenses):
    """FR3: aligned table, or a clear message when there is nothing to show."""
    if not expenses:
        print("\nNo expenses to show.")
        return
    line = "-" * 79
    print("\n%-5s %-12s %-*s %-*s %12s" % ("ID", "Date", CAT_WIDTH, "Category", DESC_WIDTH, "Description", "Amount"))
    print(line)
    for e in expenses:
        print("%-5d %-12s %-*s %-*s %12s" % (e.id, e.date, CAT_WIDTH, _fit(e.category, CAT_WIDTH),
                                              DESC_WIDTH, _fit(e.description, DESC_WIDTH), money(e.amount)))
    print(line)
    print("%d record(s)" % len(expenses))


def show_summary(summary):
    print("\n========== SUMMARY REPORT ==========")
    if summary["count"] == 0:
        print("No expenses recorded yet.")
        return
    print("Number of expenses : %d" % summary["count"])
    print("Total spent        : %s" % money(summary["total"]))
    print("Average expense    : %s" % money(summary["average"]))
    big = summary["largest"]
    print("Largest expense    : %s (%s, %s, %s)" % (money(big.amount), big.description, big.category, big.date))
    print("\nTotal per category:")
    for name, total in summary["per_category"]:
        print("  %-16s %12s" % (_fit(name, CAT_WIDTH), money(total)))
