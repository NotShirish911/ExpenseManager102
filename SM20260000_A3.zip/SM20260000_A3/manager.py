"""Business logic: the ExpenseManager class holds the records and the operations on them."""
from models import Expense
from reports import recursive_total


class ExpenseManager:
    def __init__(self, expenses=None):
        self.expenses = list(expenses) if expenses else []

    # ----- helpers -----
    def next_id(self):
        """Unique ID: one higher than the current highest ID."""
        highest = 0
        for expense in self.expenses:
            if expense.id > highest:
                highest = expense.id
        return highest + 1

    def find_by_id(self, expense_id):
        for expense in self.expenses:
            if expense.id == expense_id:
                return expense
        return None

    def categories(self):
        """Distinct category names (case-insensitive), in first-seen order."""
        seen, names = set(), []
        for expense in self.expenses:
            if expense.category.lower() not in seen:
                seen.add(expense.category.lower())
                names.append(expense.category)
        return names

    # ----- FR2, FR5, FR6 -----
    def add(self, date, category, description, amount):
        expense = Expense(self.next_id(), date, category, description, amount)
        self.expenses.append(expense)
        return expense

    def update(self, expense_id, date=None, category=None, description=None, amount=None):
        """Change the given fields. Returns False if the ID does not exist."""
        expense = self.find_by_id(expense_id)
        if expense is None:
            return False
        if date is not None:
            expense.date = date
        if category is not None:
            expense.category = category
        if description is not None:
            expense.description = description
        if amount is not None:
            expense.amount = amount
        return True

    def delete(self, expense_id):
        expense = self.find_by_id(expense_id)
        if expense is None:
            return False
        self.expenses.remove(expense)
        return True

    # ----- FR4 search (case-insensitive, may return several records) -----
    def search_description(self, keyword):
        keyword = keyword.strip().lower()
        return [e for e in self.expenses if keyword in e.description.lower()]

    def search_category(self, keyword):
        keyword = keyword.strip().lower()
        return [e for e in self.expenses if keyword in e.category.lower()]

    # ----- FR7 topic-specific operations -----
    def filter_category(self, category):
        category = category.strip().lower()
        return [e for e in self.expenses if e.category.lower() == category]

    def filter_month(self, month):
        """month is 'YYYY-MM'."""
        return [e for e in self.expenses if e.date.startswith(month)]

    def monthly_total(self, month):
        amounts = [e.amount for e in self.filter_month(month)]
        return round(recursive_total(amounts), 2)
