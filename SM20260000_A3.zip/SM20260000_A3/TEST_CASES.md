# Test cases and results

Automated: `python -m unittest discover -s tests -v` → **Ran 28 tests, OK** (all passed).

| # | Area | Input / scenario | Type | Expected result | Result |
|---|---|---|---|---|---|
| 1 | Amount | `12.5`, ` 0.01 ` | Normal / boundary | Accepted (12.5, 0.01) | Pass |
| 2 | Amount | `1000000` | Boundary | Accepted (maximum) | Pass |
| 3 | Amount | empty, spaces, `abc`, `-5`, `0`, `0.001`, `1000000.01`, `nan`, `inf`, `1e999`, `12,50` | Error | Rejected, user re-prompted | Pass |
| 4 | Date | `2026-10-31`, `2028-02-29` (leap day) | Normal / boundary | Accepted | Pass |
| 5 | Date | empty, `2026-02-30`, `2026-13-01`, `2026-1-5`, `31/10/2026`, `1999-01-01` | Error | Rejected | Pass |
| 6 | Month | `2026-10` valid; empty, `2026-13`, `2026-1`, `10-2026` invalid | Normal / error | Valid accepted, others rejected | Pass |
| 7 | Menu choice | `0`, `3` valid; empty, `x`, `-1`, `10`, `2.5` invalid | Boundary / error | Valid accepted; invalid → message, menu shown again | Pass |
| 8 | Prompt loop | amount inputs `""`, `abc`, `-1`, `0`, then `12.5` | Error | 4 error messages, then returns 12.5 | Pass |
| 9 | Prompt loop | description empty, then 61 characters, then `Coffee` | Error | Re-prompts twice, returns `Coffee` | Pass |
| 10 | Prompt loop | Enter on a field with a default (update) | Normal | Keeps current value | Pass |
| 11 | Delete confirm | `maybe`, empty, then `Y` | Error / normal | Re-prompts until Y/N | Pass |
| 12 | Recursion | `[]` and `[7.5]` | Base cases | 0.0 and 7.5 | Pass |
| 13 | Recursion | `[1.25, 2.5, 3.75, 10, 0.01]` | Normal | Equals built-in `sum` | Pass |
| 14 | Recursion | list of 20,000 items | Boundary | 20000.0, no RecursionError | Pass |
| 15 | Add | add records, delete one, add again | Normal | All IDs unique | Pass |
| 16 | Search | category `FOOD`, description `tRaIn`, description `zzz` | Normal / error | Case-insensitive; 2 results, 1 result, none | Pass |
| 17 | Filter | category `food`, month `2026-09`, month `2030-01` | Normal / error | 2, 2 and 0 records | Pass |
| 18 | Monthly total | 2026-09, 2026-10, 2030-01 | Normal / error | 100.00, 1050.00, 0.0 | Pass |
| 19 | Update | change amount and category; unknown ID 999 | Normal / error | Updated; unknown ID returns False | Pass |
| 20 | Delete | delete ID 1 twice | Normal / error | First True, second False | Pass |
| 21 | Summary | 4 sample records | Normal | Count 4, total 1150.00, average 287.50, largest Rent, per-category totals correct | Pass |
| 22 | Summary | no records | Boundary | Zeros and no largest expense, no crash | Pass |
| 23 | Summary | `Food` and `food` | Edge | Grouped as one category (15.0) | Pass |
| 24 | File | CSV file missing | Error | File and folder created, program continues | Pass |
| 25 | File | description with comma and quotes | Edge | Saved and reloaded unchanged | Pass |
| 26 | File | bad ID, bad date, negative amount, duplicate ID, short row | Error | 5 rows skipped with warnings, valid row kept | Pass |
| 27 | File | shipped `data/expenses.csv` | Normal | At least 8 valid records, no warnings | Pass |
| 28 | End-to-end | invalid menu choices, bad inputs in add/update/search/monthly total, delete declined then confirmed, exit | Error / normal | No crash; messages shown; Goodbye; data saved | Pass |
| 29 | End-to-end | add a record, exit, restart | Normal | Record is loaded on the second run | Pass |
| 30 | End-to-end | input closed (Ctrl+D / EOF) mid-session | Error | Data saved, clean goodbye | Pass |

(Rows 1–30 group related checks; some rows are covered by the same unit test.)

## Defects found and fixed during testing
[Fill this in from your own testing. Record anything that failed, how you found it and how you fixed it.]

## Manual checks to repeat in the lab
- [ ] `python main.py` starts on the lab machine and shows the menu.
- [ ] Exit with option 0 and confirm `data/expenses.csv` is updated.
- [ ] Delete `data/expenses.csv`, run the program and confirm it starts with 0 expenses and creates the file.
