"""File handling (FR9): load expenses from CSV at start-up and save them on exit."""
import csv
import os

from models import Expense, FIELDS


def save_expenses(path, expenses):
    """Write all expenses to a CSV file (with a header row), creating the folder if needed."""
    folder = os.path.dirname(path)
    if folder:
        os.makedirs(folder, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(FIELDS)
        for expense in expenses:
            writer.writerow(expense.to_row())


def load_expenses(path):
    """Return (expenses, warnings). If the file is missing it is created empty (first run)."""
    if not os.path.exists(path):
        save_expenses(path, [])
        return [], []

    expenses, warnings, seen_ids = [], [], set()
    with open(path, newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        for line_number, row in enumerate(reader, start=2):
            try:
                expense = Expense.from_row(row)
            except ValueError:
                warnings.append("Skipped invalid row on line %d." % line_number)
                continue
            if expense.id in seen_ids:
                warnings.append("Skipped duplicate ID %d on line %d." % (expense.id, line_number))
                continue
            seen_ids.add(expense.id)
            expenses.append(expense)
    return expenses, warnings
